<x-main-layout>
    <div>
        <h1 class="font-bold text-white text-3xl">CREATE ACCOUNT</h1>
        <livewire:create-account />
    </div>
</x-main-layout>

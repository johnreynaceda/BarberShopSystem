<img src="{{ asset('images/stylesynclogo.png') }}" {{ $attributes }} alt="">

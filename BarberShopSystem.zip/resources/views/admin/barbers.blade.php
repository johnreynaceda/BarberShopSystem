@section('title', 'Barbers')
<x-admin-layout>
    <div>
        <livewire:admin.all-barber-list />
    </div>
</x-admin-layout>

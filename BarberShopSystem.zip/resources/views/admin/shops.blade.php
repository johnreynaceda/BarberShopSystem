@section('title', 'Shops')
<x-admin-layout>
    <div>
        <livewire:admin.shop-list />
    </div>
</x-admin-layout>

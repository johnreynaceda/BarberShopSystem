@section('title', 'Commissions')
<x-admin-layout>
    <div>
        <livewire:admin.commission-list />
    </div>
</x-admin-layout>

<x-main-layout>
    <div>
        <h1 class="text-white font-bold text-2xl">Appointments</h1>
        <div class="mt-10">
            <livewire:customer.customer-appointment />
        </div>
    </div>
</x-main-layout>

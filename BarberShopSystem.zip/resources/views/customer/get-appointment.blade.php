<x-main-layout>
    <div>
        <livewire:customer.get-apppointment />
    </div>
</x-main-layout>

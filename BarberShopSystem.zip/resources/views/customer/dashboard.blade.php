<x-main-layout>
    <div class="bg-white p-2 rounded-xl">
        <livewire:map />
    </div>
</x-main-layout>

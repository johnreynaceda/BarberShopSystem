<div>
    <div>
        <span class="uppercase font-semibold text-xl text-main">Default Commission: {{ $percentage }}%</span>
    </div>
    <div class="mt-2">
        {{ $this->table }}
    </div>
</div>

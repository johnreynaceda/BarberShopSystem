<x-main-layout>
    <div>
        <h1 class="text-white font-bold text-2xl">APPOINTMENTS</h1>
        <div class="mt-5">
            <livewire:barber-appointment />
        </div>
    </div>
</x-main-layout>

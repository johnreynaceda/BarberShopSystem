<x-main-layout>
    <div>
        <h1 class="text-white font-bold text-2xl">TRANSACTIONS</h1>
        <div class="mt-5">
            <livewire:barber-transaction />
        </div>
    </div>
</x-main-layout>

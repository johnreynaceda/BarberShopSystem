@section('title', 'Barbers')
<x-manager-layout>
    <div>
        <livewire:manager.barber-list />
    </div>
</x-manager-layout>

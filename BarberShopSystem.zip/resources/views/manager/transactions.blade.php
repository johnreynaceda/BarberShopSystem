@section('title', 'Transactions')
<x-manager-layout>
    <div>
        <livewire:manager.shop-transaction />
    </div>
</x-manager-layout>

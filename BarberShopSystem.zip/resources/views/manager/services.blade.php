@section('title', 'Services')
<x-manager-layout>
    <div>
        <livewire:manager.service-list />
    </div>
</x-manager-layout>

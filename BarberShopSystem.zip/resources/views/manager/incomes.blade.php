@section('title', 'Incomes')
<x-manager-layout>
    <div>
        <livewire:manager.income />
    </div>
</x-manager-layout>

@section('title', 'Appointments')
<x-manager-layout>
    <div>
        <livewire:manager.shop-appointment-list />
    </div>
</x-manager-layout>

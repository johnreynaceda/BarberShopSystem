<div <?php echo e($attributes->class([
    Arr::get($roundedClasses, 'root', ''),
    Arr::get($colorClasses, 'root', ''),
    $shadowClasses => !$shadowless,
])); ?>>
    <!--[if BLOCK]><![endif]--><?php if(isset($header)): ?>
        <div <?php echo e($header->attributes); ?>>
            <?php echo e($header); ?>

        </div>
    <?php elseif($title): ?>
        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
            Arr::get($colorClasses, 'border', '') => !$borderless,
            'px-4 py-2.5 flex justify-between items-center',
            Arr::get($roundedClasses, 'header', ''),
            'border-b' => !$borderless,
        ]); ?>">
            <div <?php echo e(WireUi::extractAttributes($title)->class([
                'font-medium text-base whitespace-normal',
                Arr::get($colorClasses, 'text', ''),
            ])); ?>>
                <?php echo e($title); ?>

            </div>

            <!--[if BLOCK]><![endif]--><?php if(isset($action)): ?>
                <div <?php echo e($action->attributes); ?>>
                    <?php echo e($action); ?>

                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <div <?php echo e(WireUi::extractAttributes($slot)->class([
        Arr::get($colorClasses, 'text', ''),
        $paddingClasses,
        'grow',
    ])); ?>>
        <?php echo e($slot); ?>

    </div>

    <!--[if BLOCK]><![endif]--><?php if(isset($footer)): ?>
        <div <?php echo e($footer->attributes->class([
            Arr::get($colorClasses, 'border', '') => !$borderless,
            Arr::get($roundedClasses, 'footer', ''),
            Arr::get($colorClasses, 'footer', ''),
            'border-t' => !$borderless,
            'px-4 py-4 sm:px-6',
        ])); ?>>
            <?php echo e($footer); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH E:\FREELANCE PROJECTS\BarberShopSystem\vendor\wireui\wireui\src/Components/Card/views/index.blade.php ENDPATH**/ ?>
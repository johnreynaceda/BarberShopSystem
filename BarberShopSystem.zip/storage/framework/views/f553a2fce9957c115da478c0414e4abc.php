<?php if (isset($component)) { $__componentOriginala467e27a8a64a28aea549eeab6f9a9c7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala467e27a8a64a28aea549eeab6f9a9c7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div>
        <h1 class="text-white font-bold text-2xl">BARBER SHOPS</h1>
        <ul role="list" class="grid max-w-2xl grid-cols-1 gap-6 mx-auto mt-12 sm:gap-4 lg:max-w-none lg:grid-cols-3">
            <?php $__empty_1 = true; $__currentLoopData = \App\Models\Shop::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li class="p-2 border bg-gray-50 rounded-3xl">
                    <figure
                        class="relative flex flex-col justify-between h-full p-6 bg-white  border shadow-lg rounded-2xl">
                        <blockquote class="relative">

                        </blockquote>
                        <figcaption class="relative flex items-start justify-between ">
                            <div class="w-64">
                                <p class="font-bold uppercase text-xl text-gray-800"><?php echo e($item->name); ?> </p>

                            </div>
                            <div class="overflow-hidden rounded-full bg-gray-50">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                    viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                    stroke-linecap="round" stroke-linejoin="round"
                                    class="icon icon-tabler icons-tabler-outline icon-tabler-scissors">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                    <path d="M6 7m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0" />
                                    <path d="M6 17m-3 0a3 3 0 1 0 6 0a3 3 0 1 0 -6 0" />
                                    <path d="M8.6 8.6l10.4 10.4" />
                                    <path d="M8.6 15.4l10.4 -10.4" />
                                </svg>
                            </div>
                        </figcaption>
                        <div class="mt-3 space-y-2">
                            <div class="flex space-x-1 items-center">
                                <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22"
                                    class="text-red-500" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                    class="icon icon-tabler icons-tabler-outline icon-tabler-location-pin">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                    <path d="M12 18l-2 -4l-7 -3.5a.55 .55 0 0 1 0 -1l18 -6.5l-2.901 8.034" />
                                    <path
                                        d="M21.121 20.121a3 3 0 1 0 -4.242 0c.418 .419 1.125 1.045 2.121 1.879c1.051 -.89 1.759 -1.516 2.121 -1.879z" />
                                    <path d="M19 18v.01" />
                                </svg>
                                <p><?php echo e($item->address); ?></p>
                            </div>
                            <div class="flex space-x-1 items-center">
                                <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22"
                                    class="text-red-500" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                    class="icon icon-tabler icons-tabler-outline icon-tabler-address-book">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                    <path
                                        d="M20 6v12a2 2 0 0 1 -2 2h-10a2 2 0 0 1 -2 -2v-12a2 2 0 0 1 2 -2h10a2 2 0 0 1 2 2z" />
                                    <path d="M10 16h6" />
                                    <path d="M13 11m-2 0a2 2 0 1 0 4 0a2 2 0 1 0 -4 0" />
                                    <path d="M4 8h3" />
                                    <path d="M4 12h3" />
                                    <path d="M4 16h3" />
                                </svg>
                                <p><?php echo e($item->contact); ?></p>
                            </div>
                        </div>

                        <div class="mt-10">
                            <?php if (isset($component)) { $__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1 = $attributes; } ?>
<?php $component = WireUi\Components\Button\Base::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\WireUi\Components\Button\Base::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Get Appointment','class' => 'w-full font-semibold','right-icon' => 'arrow-right','href' => ''.e(route('customer.get-appointment', ['id' => $item->id])).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1)): ?>
<?php $attributes = $__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1; ?>
<?php unset($__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1)): ?>
<?php $component = $__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1; ?>
<?php unset($__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1); ?>
<?php endif; ?>
                        </div>
                    </figure>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>

        </ul>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala467e27a8a64a28aea549eeab6f9a9c7)): ?>
<?php $attributes = $__attributesOriginala467e27a8a64a28aea549eeab6f9a9c7; ?>
<?php unset($__attributesOriginala467e27a8a64a28aea549eeab6f9a9c7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala467e27a8a64a28aea549eeab6f9a9c7)): ?>
<?php $component = $__componentOriginala467e27a8a64a28aea549eeab6f9a9c7; ?>
<?php unset($__componentOriginala467e27a8a64a28aea549eeab6f9a9c7); ?>
<?php endif; ?>
<?php /**PATH E:\FREELANCE PROJECTS\BarberShopSystem\resources\views/customer/barber-shops.blade.php ENDPATH**/ ?>
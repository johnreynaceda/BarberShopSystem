<div>
    <?php echo e($this->table); ?>

</div>
<?php /**PATH E:\FREELANCE PROJECTS\BarberShopSystem\resources\views/livewire/customer/customer-appointment.blade.php ENDPATH**/ ?>
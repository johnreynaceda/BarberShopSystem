

<div x-data="{ open: false }"
    class="flex flex-col w-full mx-auto md:px-12 md:items-center md:justify-between md:flex-row px-8 py-2 lg:px-24 max-w-screen-xl relative">
    <div class="flex flex-row items-center justify-between text-black">
        <a class="text-md leading-normal hover:text-accent-500 font-medium flex items-center gap-2 text-base-900"
            href="#_">
            <img class="h-12 2xl:h-16" src="<?php echo e(asset('images/stylesynclogo.png')); ?>" alt="#_" />

        </a>
        <button
            class="flex items-center justify-center transition-all duration-200 focus:ring-2 transition-shadow focus:outline-none text-base-500 bg-white hover:text-accent-500 ring-1 ring-base-200 focus:ring-accent-500 size-9 p-2 text-sm rounded-md md:hidden"
            @click="open = !open">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                class="icon icon-tabler icons-tabler-outline icon-tabler-layout-grid size-3" x-data="{ open: false }">
                <!-- Paths for burger icon -->
                <path x-show="!open" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M4 6h16M4 12h16M4 18h16"></path>
                <!-- Paths for close icon (toggle icon) -->
                <path x-show="open" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M6 18L18 6M6 6l12 12"></path>
            </svg>
        </button>
    </div>
    <nav :class="{ 'flex': open, 'hidden': !open }"
        class="flex-col items-center flex-grow hidden gap-3 p-4 px-5 md:px-0 md:pb-0 md:flex md:justify-center md:flex-row lg:p-0">

        <!--[if BLOCK]><![endif]--><?php if(auth()->check()): ?>
            <?php if(auth()->user()->user_type == 'barber'): ?>
                <div class="md:ml-auto 2xl:mr-20 ">

                    <a class="<?php echo e(request()->routeIs('barber.dashboard') ? 'font-semibold' : ''); ?> px-2 py-2 text-sm  text-main hover:font-semibold hover:scale-75 focus:outline-none focus:shadow-none focus:text-black/90 md:ml-auto"
                        href="<?php echo e(route('barber.dashboard')); ?>">Appointments(<?php echo e(\App\Models\Appointment::where('barber_id', auth()->user()->barber->id)->where('status', 'pending')->get()->count()); ?>)</a>
                    <a class="<?php echo e(request()->routeIs('barber.transactions') ? 'font-semibold' : ''); ?> px-2 py-2 text-sm  text-main hover:font-semibold hover:scale-75 focus:outline-none focus:shadow-none focus:text-black/90 md:ml-auto"
                        href="<?php echo e(route('barber.transactions')); ?>">Transaction(<?php echo e(\App\Models\Transaction::where('barber_id', auth()->user()->barber->id)->where('status', 'pending')->get()->count()); ?>)</a>

                </div>
            <?php elseif(auth()->user()->user_type == 'customer'): ?>
                <div class="md:ml-auto">
                    <a class="<?php echo e(request()->routeIs('customer.dashboard') ? 'font-semibold' : ''); ?> px-2 py-2 text-sm  text-main hover:font-semibold hover:scale-75 focus:outline-none focus:shadow-none focus:text-black/90 md:ml-auto"
                        href="<?php echo e(route('customer.dashboard')); ?>">Home </a>
                    <a class="<?php echo e(request()->routeIs('customer.barber-shops') ? 'font-semibold' : ''); ?> px-2 py-2 text-sm  text-main hover:font-semibold hover:scale-75 focus:outline-none focus:shadow-none focus:text-black/90 md:ml-auto"
                        href="<?php echo e(route('customer.barber-shops')); ?>">Barber Shops </a>
                    <a class="<?php echo e(request()->routeIs('customer.appointment') ? 'font-semibold' : ''); ?> px-2 py-2 text-sm  text-main hover:font-semibold hover:scale-75 focus:outline-none focus:shadow-none focus:text-black/90 md:ml-auto"
                        href="<?php echo e(route('customer.appointments')); ?>">Appointments</a>
                    <a class="px-2 py-2 text-sm  text-main hover:font-semibold hover:scale-75 focus:outline-none focus:shadow-none focus:text-black/90 md:ml-auto"
                        href="#features">Notifications</a>
                </div>
            <?php else: ?>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('customer-userdropdown', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1389329098-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <?php else: ?>
            <a class="px-4 py-2 text-xs text-gray-500 hover:text-black focus:outline-none focus:shadow-none focus:text-black/90 md:ml-auto"
                href="#features">Features </a>
            <?php if (isset($component)) { $__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1 = $attributes; } ?>
<?php $component = WireUi\Components\Button\Base::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\WireUi\Components\Button\Base::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Sign In','href' => ''.e(route('register')).'','class' => 'font-semibold','slate' => true,'rounded' => 'lg']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1)): ?>
<?php $attributes = $__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1; ?>
<?php unset($__attributesOriginalf04362c37f55b087f96f1c4fb07d5ce1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1)): ?>
<?php $component = $__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1; ?>
<?php unset($__componentOriginalf04362c37f55b087f96f1c4fb07d5ce1); ?>
<?php endif; ?>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </nav>
</div>
<?php /**PATH E:\FREELANCE PROJECTS\BarberShopSystem\resources\views/livewire/navbar.blade.php ENDPATH**/ ?>
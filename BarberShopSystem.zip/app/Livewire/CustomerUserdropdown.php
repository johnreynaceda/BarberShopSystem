<?php

namespace App\Livewire;

use Livewire\Component;

class CustomerUserdropdown extends Component
{
    public function render()
    {
        return view('livewire.customer-userdropdown');
    }
}
